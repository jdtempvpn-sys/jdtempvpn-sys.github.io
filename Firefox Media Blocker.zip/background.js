browser.webRequest.onBeforeRequest.addListener(
  () => {return {cancel: true}},
  { urls: ["*://pbs.twimg.com/*", "*://video.twimg.com/*", "*://external-preview.redd.it/*"] },
  ["blocking"],
);