const keys = {
    preferences: 'preferences',
    settings: 'settings',
    savedState: 'savedState'
}

coll = Array.from(document.getElementsByTagName('input'))

browser.runtime.sendMessage('get-storage-options', result => {
    if (Object.keys(result).length) {
        result[keys.settings].forEach(item => {
            var input = coll.find(elem => {return elem.name == item.name})

            var value = input.getAttribute('category') == 'default' ? item.default : item.max

            switch (item.name.toLowerCase()) {
                case 'brightness':
                case 'saturate':
                case 'contrast':
                case 'opacity':
                    value = Number(value) * 10
                    break
                default:
                    break
            }

            input.placeholder = value
        })
    }
})

coll.forEach(item => {
    item.oninput = function (e) {
        

        browser.runtime.sendMessage({
            type: 'set-storage-options',
            key: keys.settings,
            value: item.value,
            name: item.name
        })
    }
})