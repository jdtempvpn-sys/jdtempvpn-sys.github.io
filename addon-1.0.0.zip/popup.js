//document.addEventListener('DOMContentLoaded', init)

init()

function init() {
	var coll = document.querySelectorAll('.property-container')
	if (coll.length == 9) {
		exec()
		return
	}

	setTimeout(init, 100)
}

function exec() {
    const DEFAULT = [
		{
			name: 'Brightness',
			value: 1
		},
		{
			name: 'Saturate',
			value: 1
		},
		{
			name: 'Contrast',
			value: 1
		},
		{
			name: 'Opacity',
			value: 1
		},
		{
			name: 'Blur',
			value: 0,
			abrv: 'px'
		},
		{
			name: 'Hue-Rotate',
			value: 0,
			abrv: 'deg'
		},
		{
			name: 'Grayscale',
			value: 0
		},
		{
			name: 'Invert',
			value: 0
		},
		{
			name: 'Sepia',
			value: 0
		}
	]
    const keys = {
		preferences: 'preferences',
		settings: 'settings',
		savedState: 'savedState'
	}

	// define display property object
	class DisplayProperty {
		constructor (heading, input, label = null) {
			this.name = heading.innerText,
			this.value = 1,
			this.input = input,
			this.heading = heading,
			this.label = label,
			this.abrv = null
		}

		get value() {
			return Number(this.input.value)
		}

		toString() {
			if (this.label) {
				return this.label.innerText	
			}

			return this.heading.innerText
		}

		set value(v) {
			if (typeof v == 'object' && v.length && v.length > 1) {
				let number = typeof v[0] == 'number' ? 0 : typeof v[1] == 'number' ? 1 : null
				if (number == null) {
					console.error('Type error: type mismatch!')
					return
				}
				let abrv = number ? 0 : 1
				this.abrv = v[abrv].toLowerCase()
				let symbol = this.abrv == 'deg' ? String.fromCharCode(176) : ' pixels'

				try {
					this.label.innerText = String(v[number]) + symbol
					this.input.value = v[number]
				} catch (err) {}
			} else {
				try {
					if (this.label) {
						this.label.innerText = String(v)
					} else {
						this.input.checked = v == '1' ? true : false
					}

					this.input.value = v
				} catch (err) {}
			}
		}
	}
    
	// get display properties as DisplayProperty objects and store in array
	displayProperties = getDisplayProperties()

	function getDisplayProperties() {
		// get display property containers
		var propContainers = document.querySelectorAll('.property-container')

		// create display property objects
		var displayProperties = []

		propContainers.forEach(container => {
			var prop = new DisplayProperty(container.querySelector('p'), container.querySelector('input'), container.querySelector('.label'))
			displayProperties.push(prop) 
		})

		return displayProperties
	}

    // update page on input changed
	displayProperties.forEach(prop => {
		prop.input.oninput = function (e) {
			if (this.label) {
				this.label.innerText = `${this.value}${!this.abrv ? '' : this.name.toLowerCase() == 'blur' ? (this.value == 1 ? ' pixel' : ' pixels') : String.fromCharCode(176)}`
			} else {
				this.value = this.input.checked ? 1 : 0
			}
			
			browser.runtime.sendMessage(
				{
					type: 'update',
					property: {
						name: this.name,
						value: this.value,
						abrv: this.abrv
					}
				}
			)
		}.bind(prop)
	})

    // save settings site/page settings
	// TODO: save page settings
    saveButtons = document.getElementsByClassName('save-button')
	
	Array.from(saveButtons).forEach(button => {
		button.addEventListener('click', function (e) {
			browser.runtime.sendMessage(
				{
					type: 'save-preferences',
					key: keys.preferences,
					domain: e.target.value == 'Save Site' ? true : false
				},
				function (resp) { }
			)
			
			// TODO: consider
			//window.close()
		})
	})

	resetButton = document.getElementById('reset')
	resetButton.addEventListener('click', function (e) {
		browser.runtime.sendMessage({type: 'get-default'}, resp => {
			if (Object.keys(resp).length) {
				resp.forEach(setPreference)
			} else {
				DEFAULT.forEach(setPreference)
			}
		})
	})

	function getPage() {
		// get current settings from page
		browser.runtime.sendMessage(
			{ type: 'get-page'},
			function (resp) {
				if (resp) {
					preferences = resp
					
					resp.forEach(setPreference)

					var arr = displayProperties.map(property => {return property.input}).concat(Array.from(saveButtons)).concat(resetButton)
					
					arr.forEach(property => {
						property.disabled = false
					})

				} else {
					setTimeout(getPage, 100)
				}
			}
		)
	}

	getPage()

    // set settings values
    function setPreference(obj) {
		let property = displayProperties[displayProperties.findIndex(elem => {return elem.name == obj.name})]

		switch (property.name.toLowerCase()) {
			case 'brightness':
			case 'saturate':
			case 'contrast':
			case 'opacity':
			case 'grayscale':
			case 'invert':
			case 'sepia':
				property.value = obj.value
				break
			case 'blur':
			case 'hue-rotate':
				property.value = [obj.value, obj.abrv]
				break
			default:
				break
		}

		property.input.dispatchEvent(new Event('input'))
    }
}
