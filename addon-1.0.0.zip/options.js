var button = document.getElementById('main-control')

var className = {
    enabled: 'enabled',
    disabled: 'disabled'
}

var inputValue = {
    enabled: 'Enabled',
    disabled: 'Disabled'
}

function enableControl(e) {
    e.target.classList.add(className.enabled)
    e.target.classList.remove(className.disabled)
}

function disableControl(e) {
    e.target.classList.remove(className.enabled)
    e.target.classList.add(className.disabled)
}

function invertControlState(e) {
    if (e.target.classList.contains(className.disabled)) {
        enableControl(e)
        e.target.value = inputValue.enabled
    } else if (e.target.classList.contains(className.enabled)) {
        disableControl(e)
	e.target.value = inputValue.disabled
    }
}

button.addEventListener('click', invertControlState)